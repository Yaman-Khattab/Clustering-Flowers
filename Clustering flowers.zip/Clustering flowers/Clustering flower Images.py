from keras.preprocessing.image import load_img 
from keras.preprocessing.image import img_to_array 
from keras.applications.vgg16 import preprocess_input 
from keras.applications.vgg16 import VGG16 
from keras.models import Model
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import os
import numpy as np
import matplotlib.pyplot as plt
from random import randint
import pandas as pd
import pickle
import os
import cv2
import glob
import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


flowers = glob.glob('../input/flower-color-images/flower_images/flower_images/*.png')


# load the model first and pass as an argument
model = VGG16()
# getting the input of model and its output. cutting off the last layer
model = Model(inputs = model.inputs, outputs = model.layers[-2].output)


def extract_features(file, model):
    # load the image as a 224x224 array because the model expect to get image of that size
    img = load_img(file, target_size=(224,224))
    # convert from Image to numpy array
    img = np.array(img) 
    # reshape the data for the model 
    reshaped_img = img.reshape(1,224,224,3) 
    # prepare image for model
    imgx = preprocess_input(reshaped_img)
    # get the feature vector
    features = model.predict(imgx, use_multiprocessing=True)
    return features

data = {}

# lop through each image in the dataset to extract its features
for flower in flowers:
    feat = extract_features(flower,model)
    data[flower] = feat
    
# get a list of the filenames
filenames = np.array(list(data.keys()))
# get a list of the features
feat = np.array(list(data.values()))


#To convert the shape of a NumPy array 
# The length of the dimension set to -1 is automatically determined by inferring from the specified values of other dimensions
feat = feat.reshape(-1,4096)

# Reduce the number variables we have to 100, Since our feature has 4096
pca = PCA(n_components=100, random_state=22)
pca.fit(feat)
x = pca.transform(feat)

# n_jobs: using all processors for the computation
# random_state: generation for centroid initializatio
# Clustering the 100 components we have into 10 categories

kmeans = KMeans(n_clusters=10,n_jobs=-1, random_state=22)
kmeans.fit(x)
model.summary()
# holds the cluster in dictionary id and the images attributes
groups = {}
for file, cluster in zip(filenames,kmeans.labels_):
    if cluster not in groups.keys():
        groups[cluster] = []
        groups[cluster].append(file)
    else:
        groups[cluster].append(file)

# function that lets you view a cluster (based on identifier)        
def view_cluster(cluster):
    plt.figure(figsize = (25,25));
    # gets the list of filenames for a cluster
    files = groups[cluster]
    # only allow up to 20 images to be shown at a time
    if len(files) > 21:
        files = files[:20]
    # plot each image in the cluster
    for index, file in enumerate(files):
        plt.subplot(10,10,index+1);
        img = load_img(file)
        img = np.array(img)
        plt.imshow(img)
        plt.axis('off')
       

view_cluster(5)
view_cluster(9)
view_cluster(3)